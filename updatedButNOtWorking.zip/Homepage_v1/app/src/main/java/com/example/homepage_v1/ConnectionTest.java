package com.example.homepage_v1;

import androidx.annotation.LongDef;
import androidx.annotation.MainThread;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.internal.ICameraUpdateFactoryDelegate;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

public class ConnectionTest
        extends FragmentActivity implements OnMapReadyCallback {
    EditText textToBeSent, ipAddress , portNumber;
    TextView receivedText;
    Button start, network, status , reset;
    public static InetAddress ip;
    public static int port;
    public static String messageToBeSent;
    public static String messageReceived;
    public Socket socket = null;
    public static final byte[] buffer = new byte[1024];
    public static final int ITERATION = 1000;
    public static final String FINISHED_STATUS = "Finished";
    public static Boolean isClicked = false;
    GoogleMap map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connnection_test);
        textToBeSent = findViewById(R.id.textToBeSent);
        ipAddress = findViewById(R.id.ipAddress);
        receivedText = findViewById(R.id.receivedText);
        portNumber = findViewById(R.id.portNumber);
        start = findViewById(R.id.start);
        network = findViewById(R.id.findNetwork);
        status = findViewById(R.id.status);
        final Handler handler = new Handler();
        reset = findViewById(R.id.reset);

        // We need to either create a new Thread OR use the below line
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitNetwork().build();
        StrictMode.setThreadPolicy(policy);

        setTitle("Client-8");
                SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

//        status.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if(socket == null){
//                    Toast.makeText(ConnectionTest.this, "Socket is null", Toast.LENGTH_SHORT).show();
//                } else if(socket != null && socket.isConnected()){
//                    Toast.makeText(ConnectionTest.this, "Socket is connected", Toast.LENGTH_SHORT).show();
//                } else if (socket != null && !socket.isConnected()){
//                    Toast.makeText(ConnectionTest.this, "Socket is not connected", Toast.LENGTH_SHORT).show();
//                } else{
//                    Toast.makeText(ConnectionTest.this,"Failure",Toast.LENGTH_SHORT).show();
//                }
//            }
//        });


//        reset.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if(socket != null){
//                    try {
//                        socket.close();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                } else {
//                    Toast.makeText(ConnectionTest.this,"Socket is already closed",Toast.LENGTH_SHORT).show();
//                }
//            }
//        });


        network.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isClicked == false) {
                    try {
                        port = Integer.parseInt(portNumber.getText().toString());
                        ip = InetAddress.getByName(ipAddress.getText().toString());
                        Client client = new Client();
                        client.run();
                        socket = client.socketGetter();
                        if (socket != null && socket.isConnected()) {
                            Toast.makeText(ConnectionTest.this, "Connection succeeded on port " + ip.getHostName(), Toast.LENGTH_SHORT).show();
                            isClicked = true;
                        } else if (socket != null && !socket.isConnected()) {
                            Toast.makeText(ConnectionTest.this, "socket is not connected ", Toast.LENGTH_SHORT).show();
                        } else if (socket == null) {
                            Toast.makeText(ConnectionTest.this, "socket is not created ", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    Toast.makeText(ConnectionTest.this, "You already clicked", Toast.LENGTH_SHORT).show();
                }

            }
        });

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //int Count = 0;
                //messageToBeSent = textToBeSent.getText().toString();

                while (true) {

                    //long time0 = System.currentTimeMillis();

                    ReceiveData receiveData = new ReceiveData(socket);
                    receiveData.run();

                }
                //handler.post(() -> receivedText.setText(messageReceived));
                //isClicked = false;

            }
        });
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;

        LatLng Northcarolina = new LatLng(35.3036, -80.7324);
        map.addMarker(new MarkerOptions().position(Northcarolina).title("Northcarolina"));
        map.moveCamera(CameraUpdateFactory.newLatLng(Northcarolina));
    }
    class Client implements Runnable{
        Socket socket;
        public Client(){
        }

        @Override
        public void run() {
            try {
                socket = new Socket(ip,port);
                Toast.makeText(ConnectionTest.this,"created my socket",Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(ConnectionTest.this,"Task failed in creating a socket",Toast.LENGTH_SHORT).show();
            }
        }

        public Socket socketGetter(){
            return this.socket;
        }
    }


//    class SendData extends Thread{
//        Socket socket;
//
//        public SendData(Socket socket) {
//            this.socket = socket;
//
//        }
//
//        @Override
//        public void run() {
//            DataOutputStream dataOutputStream = null;
//            try {
//                dataOutputStream = new DataOutputStream(socket.getOutputStream());
//            } catch (IOException e) {
//                e.printStackTrace();
//                Toast.makeText(ConnectionTest.this, "Something went wrong", Toast.LENGTH_SHORT).show();;
//            }
//            try {
//                dataOutputStream.writeUTF(messageToBeSent);
//            } catch (IOException e) {
//                e.printStackTrace();
//                Toast.makeText(ConnectionTest.this, "Something went wrong", Toast.LENGTH_SHORT).show();;
//            }
//        }
//    }


    class ReceiveData extends Thread {
        Socket socket;
        int iteration;

        public ReceiveData(Socket socket){
            this.socket = socket;
            //this.iteration = iteration;
        }
        @Override
        public void run() {
            int bytes;
            String latitude;
            String longitude;
            String temp;
            DataInputStream dataInputStream = null;
            try {
                dataInputStream = new DataInputStream(socket.getInputStream());
                //bytes = dataInputStream.read(buffer);
                temp = dataInputStream.readUTF();
                latitude = temp.split(",")[0];
                longitude = temp.split(",")[1];
//                if(iteration != ITERATION){
//                    messageReceived = new String((byte[]) buffer, 0, bytes);
//                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}