package com.example.homepage_v1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.internal.ICameraUpdateFactoryDelegate;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends FragmentActivity {
    private Button button;

//    GoogleMap map;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//
//        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
//                .findFragmentById(R.id.map);
//        mapFragment.getMapAsync(this);

        button = (Button) findViewById(R.id.Test);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openConnectionTest();
            }

        });
    }

    public void openConnectionTest() {
        Intent intent = new Intent(this, ConnectionTest.class);
        startActivity(intent);
    }

//    @Override
//    public void onMapReady(GoogleMap googleMap) {
//        map = googleMap;
//
//        LatLng Northcarolina = new LatLng(35.3036, -80.7324);
//        map.addMarker(new MarkerOptions().position(Northcarolina).title("Northcarolina"));
//        map.moveCamera(CameraUpdateFactory.newLatLng(Northcarolina));
//    }
}